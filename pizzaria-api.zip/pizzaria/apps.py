from django.apps import AppConfig


class PizzariaConfig(AppConfig):
    name = 'pizzaria'
